# HOGAN AI
Sistema armonico con integrazione OpenAI via API
