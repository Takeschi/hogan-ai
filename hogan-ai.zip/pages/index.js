
import { useState } from 'react';

export default function Home() {
  const [input, setInput] = useState('');
  const [response, setResponse] = useState('');

  const handleSubmit = async () => {
    const res = await fetch('/api/hogan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: input }),
    });
    const data = await res.json();
    setResponse(data.choices?.[0]?.message?.content || 'No response');
  };

  return (
    <main style={{ backgroundColor: '#000', color: '#0ff', minHeight: '100vh', padding: '2rem', fontFamily: 'monospace' }}>
      <h1>HOGAN AI</h1>
      <textarea rows={4} value={input} onChange={(e) => setInput(e.target.value)} placeholder="Chiedi a HOGAN..." style={{ width: '100%', marginBottom: '1rem' }} />
      <button onClick={handleSubmit}>Invia</button>
      <pre>{response}</pre>
    </main>
  );
}
