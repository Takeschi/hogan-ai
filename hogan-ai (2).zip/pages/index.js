export default function Home() {
  return (
    <div style={{ background: '#000', color: '#0ff', height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <h1>✨ Welcome to HOGAN AI ✨</h1>
    </div>
  );
}